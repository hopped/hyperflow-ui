#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/hyperflow-ui" -importPath hyperflow-ui -srcPath "$SCRIPTPATH/src" -runMode prod
